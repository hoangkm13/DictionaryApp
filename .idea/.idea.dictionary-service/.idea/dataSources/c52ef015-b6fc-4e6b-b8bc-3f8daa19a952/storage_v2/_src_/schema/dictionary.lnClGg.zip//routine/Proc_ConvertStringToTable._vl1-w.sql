create
    definer = root@localhost procedure Proc_ConvertStringToTable(IN $lstValue text, IN $SeparateCharacter char)
    sql security invoker
BEGIN
    DECLARE
        $strJson longtext;
    SET
        $strJson = CONCAT('[{"a":"', REPLACE($lstValue, $SeparateCharacter, '"},{"a":"'), '"}]');
    DROP
        TEMPORARY TABLE IF EXISTS tmpListConvert;
    CREATE
        TEMPORARY TABLE tmpListConvert
    (
        value varchar(500)
    ) COLLATE utf8mb4_general_ci;

    IF
        JSON_VALID($strJson) = 1 THEN
        INSERT INTO tmpListConvert
        SELECT *
        FROM JSON_TABLE($strJson, "$[*]" COLUMNS (
      a varchar(500) PATH "$.a"
      )
         ) AS tt;
    END IF;
END;


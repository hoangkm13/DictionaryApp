create
    definer = root@localhost procedure Proc_GenEntity(IN tableName varchar(150))
    comment 'Tạo Entity'
    sql security invoker
BEGIN
    SELECT field
    FROM (SELECT CONCAT('public ',
                        CASE
                            WHEN
                                        DATA_TYPE = 'char' AND
                                        CHARACTER_MAXIMUM_LENGTH = 36 THEN 'Guid'
                            WHEN DATA_TYPE = 'bit' THEN 'bool'
                            WHEN
                                DATA_TYPE = 'int' THEN 'int'
                            WHEN DATA_TYPE = 'bidgint' THEN 'long'
                            WHEN
                                DATA_TYPE = 'tinyint' THEN 'int'
                            WHEN DATA_TYPE = 'double' THEN 'decimal'
                            WHEN
                                DATA_TYPE = 'decimal' THEN 'decimal'
                            WHEN DATA_TYPE = 'float' THEN 'decimal'
                            WHEN
                                DATA_TYPE = 'date' THEN 'DateTime'
                            WHEN DATA_TYPE = 'datetime' THEN 'DateTime'
                            WHEN
                                DATA_TYPE = 'timestamp' THEN 'DateTime'
                            ELSE 'string' END,
                        ' ',
                        CASE IS_NULLABLE WHEN 'YES' THEN '?' ELSE '' END,
                        ' ',
                        column_name,
                        ' {get;set;}') AS field,
                 100                   AS gp,
                 ordinal_position      AS so
          FROM information_schema.COLUMNS
          WHERE TABLE_NAME = tableName
            AND TABLE_SCHEMA = 'dictionary'
          UNION ALL
          SELECT '/// <summary>',
                 10,
                 ordinal_position
          FROM information_schema.COLUMNS
          WHERE TABLE_NAME = tableName
            AND TABLE_SCHEMA = 'dictionary'
          UNION ALL
          SELECT CONCAT('/// ',
                        CASE
                            WHEN
                                        column_key = 'PRI' AND
                                        (column_comment IS NULL OR
                                         column_comment = '') THEN 'PK'
                            ELSE column_comment END),
                 20,
                 ordinal_position
          FROM information_schema.COLUMNS
          WHERE TABLE_NAME = tableName
            AND TABLE_SCHEMA = 'dictionary'
          UNION ALL
          SELECT '/// <summary>',
                 30,
                 ordinal_position
          FROM information_schema.COLUMNS
          WHERE TABLE_NAME = tableName
            AND TABLE_SCHEMA = 'dictionary'
          UNION ALL
          SELECT '[Key]',
                 40,
                 ordinal_position
          FROM information_schema.COLUMNS
          WHERE TABLE_NAME = tableName
            AND column_key = 'PRI'
            AND TABLE_SCHEMA = 'dictionary'
          UNION ALL
          SELECT '/// <summary>',
                 -30,
                 0
          UNION ALL
          SELECT CONCAT('/// ', table_comment),
                 -29,
                 0
          FROM information_schema.tables
          WHERE TABLE_NAME = tableName
            AND TABLE_SCHEMA = 'dictionary'
          UNION ALL
          SELECT '/// <summary>',
                 -28,
                 0
          UNION ALL
          SELECT CONCAT('[Table("', LOWER(tableName), '")]'),
                 -10,
                 0
          UNION ALL
          SELECT CONCAT('public class ', SnakeToPascal(tableName), 'Entity'),
                 -9,
                 0
          UNION ALL
          SELECT '{',
                 -8,
                 0
          UNION ALL
          SELECT '}',
                 1000,
                 1000) AS T
    ORDER BY so, gp;

END;


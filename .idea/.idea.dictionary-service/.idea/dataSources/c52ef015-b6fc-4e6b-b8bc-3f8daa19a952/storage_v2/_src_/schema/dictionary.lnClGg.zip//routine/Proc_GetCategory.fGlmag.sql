create
    definer = root@localhost procedure Proc_GetCategory() comment 'Lấy danh sách Loại sản phẩm' sql security invoker
BEGIN
    SELECT c.category_name,
           c.category_id,
           c.created_date,
           COUNT(p.product_id) AS product_count
    FROM product p
             JOIN product_category pc
                  ON p.product_id = pc.product_id
             JOIN category c
                  ON pc.category_id = c.category_id
    GROUP BY c.category_name,
             c.category_id,
             c.created_date
    ORDER BY product_count DESC;

END;


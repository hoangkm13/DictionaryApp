create
    definer = root@localhost procedure Proc_GetCommentProduct(IN $product_id char(36), IN $filterCode varchar(20),
                                                              IN $pageNumber int, IN $pageSize int)
    comment 'Lấy bình luận đánh giá của 1 sản phẩm'
    sql security invoker
BEGIN
    DECLARE
        $Count int;
    DECLARE
        $offset int;
    SET
        $offset = $pageNumber * $pageSize;
    IF
        $filterCode = 'All' THEN
        BEGIN
            SELECT COUNT(*)
            INTO $Count
            FROM comment c
            WHERE c.product_id = $product_id;
            SELECT c.*,
                   u.email,
                   u.avatar,
                   $Count AS count_comment
            FROM comment c
                     LEFT JOIN user u
                               ON c.user_id = u.user_id
            WHERE c.product_id = $product_id
            ORDER BY c.created_date DESC
            LIMIT $pageSize OFFSET $offset;
        END;
    ELSEIF
        $filterCode = 'Five' THEN
        BEGIN
            SELECT COUNT(*)
            INTO $Count
            FROM comment c
            WHERE c.product_id = $product_id
              AND c.rate = 5;
            SELECT c.*,
                   u.email,
                   u.avatar,
                   $Count AS count_comment
            FROM comment c
                     LEFT JOIN user u
                               ON c.user_id = u.user_id
            WHERE c.product_id = $product_id
              AND c.rate = 5
            ORDER BY c.created_date DESC
            LIMIT $pageSize OFFSET $offset;
        END;
    ELSEIF
        $filterCode = 'Four' THEN
        BEGIN
            SELECT COUNT(*)
            INTO $Count
            FROM comment c
            WHERE c.product_id = $product_id
              AND c.rate = 4;
            SELECT c.*,
                   u.email,
                   u.avatar,
                   $Count AS count_comment
            FROM comment c
                     LEFT JOIN user u
                               ON c.user_id = u.user_id
            WHERE c.product_id = $product_id
              AND c.rate = 4
            ORDER BY c.created_date DESC
            LIMIT $pageSize OFFSET $offset;
        END;
    ELSEIF
        $filterCode = 'Three' THEN
        BEGIN
            SELECT COUNT(*)
            INTO $Count
            FROM comment c
            WHERE c.product_id = $product_id
              AND c.rate = 3;
            SELECT c.*,
                   u.email,
                   u.avatar,
                   $Count AS count_comment
            FROM comment c
                     LEFT JOIN user u
                               ON c.user_id = u.user_id
            WHERE c.product_id = $product_id
              AND c.rate = 3
            ORDER BY c.created_date DESC
            LIMIT $pageSize OFFSET $offset;
        END;
    ELSEIF
        $filterCode = 'Two' THEN
        BEGIN
            SELECT COUNT(*)
            INTO $Count
            FROM comment c
            WHERE c.product_id = $product_id
              AND c.rate = 2;
            SELECT c.*,
                   u.email,
                   u.avatar,
                   $Count AS count_comment
            FROM comment c
                     LEFT JOIN user u
                               ON c.user_id = u.user_id
            WHERE c.product_id = $product_id
              AND c.rate = 2
            ORDER BY c.created_date DESC
            LIMIT $pageSize OFFSET $offset;
        END;
    ELSEIF
        $filterCode = 'One' THEN
        BEGIN
            SELECT COUNT(*)
            INTO $Count
            FROM comment c
            WHERE c.product_id = $product_id
              AND c.rate = 1;
            SELECT c.*,
                   u.email,
                   u.avatar,
                   $Count AS count_comment
            FROM comment c
                     LEFT JOIN user u
                               ON c.user_id = u.user_id
            WHERE c.product_id = $product_id
              AND c.rate = 1
            ORDER BY c.created_date DESC
            LIMIT $pageSize OFFSET $offset;
        END;
    ELSEIF
        $filterCode = 'HaveContent' THEN
        BEGIN
            SELECT COUNT(*)
            INTO $Count
            FROM comment c
            WHERE c.product_id = $product_id
              AND c.content IS NOT NULL
              AND c.content <> '';
            SELECT c.*,
                   u.email,
                   u.avatar,
                   $Count AS count_comment
            FROM comment c
                     LEFT JOIN user u
                               ON c.user_id = u.user_id
            WHERE c.product_id = $product_id
              AND c.content IS NOT NULL
              AND c.content <> ''
            ORDER BY c.created_date DESC
            LIMIT $pageSize OFFSET $offset;
        END;
    ELSEIF
        $filterCode = 'HaveImage' THEN
        BEGIN
            SELECT COUNT(*)
            INTO $Count
            FROM comment c
            WHERE c.product_id = $product_id
              AND c.img_url IS NOT NULL
              AND c.img_url <> '';
            SELECT c.*,
                   u.email,
                   u.avatar,
                   $Count AS count_comment
            FROM comment c
                     LEFT JOIN user u
                               ON c.user_id = u.user_id
            WHERE c.product_id = $product_id
              AND c.img_url IS NOT NULL
              AND c.img_url <> ''
            ORDER BY c.created_date DESC
            LIMIT $pageSize OFFSET $offset;
        END;
    END IF;
END;


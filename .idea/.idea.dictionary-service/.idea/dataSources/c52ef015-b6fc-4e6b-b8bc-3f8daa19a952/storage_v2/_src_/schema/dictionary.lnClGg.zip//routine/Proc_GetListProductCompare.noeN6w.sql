create
    definer = root@`%` procedure Proc_GetListProductCompare(IN $ProductId char(36))
    comment 'Lấy danh sách sản phẩm để so sánh'
BEGIN
    -- Lấy danh sách id nhóm sản phẩm của sp so sánh
    DROP
        TEMPORARY TABLE IF EXISTS tmpListCategoryProduct;
    CREATE
        TEMPORARY TABLE tmpListCategoryProduct
    SELECT pc.product_category_id,
           pc.product_id,
           pc.category_id
    FROM product_category pc
    WHERE pc.category_id IN (SELECT pc1.category_id
                             FROM product_category pc1
                             WHERE pc1.product_id = $ProductId)
      AND pc.product_id <> $ProductId;

    SELECT p.product_name,
           p.product_id
    FROM tmpListCategoryProduct tlcp
             INNER JOIN product p
                        ON tlcp.product_id = p.product_id
    WHERE p.status = 1;
END;


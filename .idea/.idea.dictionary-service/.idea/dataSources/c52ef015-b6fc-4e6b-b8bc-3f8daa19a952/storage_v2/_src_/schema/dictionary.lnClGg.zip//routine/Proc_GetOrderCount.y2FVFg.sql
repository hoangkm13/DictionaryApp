create
    definer = root@localhost procedure Proc_GetOrderCount(IN $user_id char(36))
    comment 'Lấy số lượng đơn hàng theo trạng thái'
    sql security invoker
BEGIN
    DECLARE
        $All int;
    DECLARE
        Acceipt int;
    DECLARE
        Pending int;
    DECLARE
        Delivering int;
    DECLARE
        Delivered int;
    DECLARE
        Cancelled int;
    DECLARE
        Undelivered int;

    SELECT COUNT(*)
    INTO $All
    FROM `order` o
    WHERE o.user_id = $user_id;
    SELECT COUNT(*)
    INTO Acceipt
    FROM `order` o
    WHERE o.user_id = $user_id
      AND o.status = 5;
    SELECT COUNT(*)
    INTO Pending
    FROM `order` o
    WHERE o.user_id = $user_id
      AND o.status = 2;
    SELECT COUNT(*)
    INTO Delivering
    FROM `order` o
    WHERE o.user_id = $user_id
      AND o.status = 3;
    SELECT COUNT(*)
    INTO Delivered
    FROM `order` o
    WHERE o.user_id = $user_id
      AND o.status = 1;
    SELECT COUNT(*)
    INTO Cancelled
    FROM `order` o
    WHERE o.user_id = $user_id
      AND o.status = 4;
    SELECT COUNT(*)
    INTO Undelivered
    FROM `order` o
    WHERE o.user_id = $user_id
      AND o.status = 7;

    DROP
        TEMPORARY TABLE IF EXISTS result;
    CREATE
        TEMPORARY TABLE result
    (
        `All`       int,
        Acceipt     int,
        Pending     int,
        Delivering  int,
        Delivered   int,
        Cancelled   int,
        Undelivered int
    );

    INSERT INTO result (`All`, Acceipt, Pending, Delivering, Delivered, Cancelled, Undelivered)
    VALUES ($All, Acceipt, Pending, Delivering, Delivered, Cancelled, Undelivered);

    SELECT *
    FROM result;

END;


create
    definer = root@`%` procedure Proc_GetOrderDashboard() comment 'Lấy danh sách đơn hàng'
BEGIN
    SELECT o.order_id,
           o.order_code,
           CONCAT(u.first_name, '', u.last_name) AS buy_name,
           o.user_name
    FROM `order` o
             LEFT JOIN product_order po
                       ON o.order_id = po.order_id
             LEFT JOIN user u
                       ON o.user_id = u.user_id;
END;


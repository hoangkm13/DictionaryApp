create
    definer = root@localhost procedure Proc_GetProductAttribute(IN $productId char(36))
    comment 'Lấy thuộc tính của sản phẩm'
    sql security invoker
BEGIN
    SELECT pa.product_attribute_id,
           pa.attribute_id,
           pa.product_id,
           pa.value,
           pa.created_date,
           a.attribute_name,
           2 AS state
    FROM product_attribute pa
             LEFT JOIN attribute a
                       ON pa.attribute_id = a.attribute_id
    WHERE pa.product_id = $productId;
END;


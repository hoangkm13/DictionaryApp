create
    definer = root@localhost procedure Proc_GetProductHome(IN $keyword varchar(255), IN $rating int,
                                                           IN $fromAmount decimal, IN $toAmount decimal,
                                                           IN $category text, IN $sort int, IN $page int,
                                                           IN $pageSize int)
    comment 'Lấy danh sách sản phẩm trang home page có tìm kiếm, sắp xếp,...'
    sql security invoker
BEGIN
    DECLARE
        $totalRecord int;
    DECLARE
        $offset int;
    SET
        $offset = $page * $pageSize;

    DROP
        TEMPORARY TABLE IF EXISTS result1;
    CREATE
        TEMPORARY TABLE result1 COLLATE utf8mb4_general_ci
    SELECT pd.product_id,
           COUNT(pd.product_detail_id)                        AS count_detail, -- số sản phẩm trong 1 loại sp
           GROUP_CONCAT(IFNULL(pd.img_url, '') SEPARATOR ';') AS img_url,
           MAX(pd.sale_price)                                 AS sale_price_max,
           MIN(pd.sale_price)                                 AS sale_price_min,
           MAX(pd.sale_price_old)                             AS sale_price_old,
           MAX(pd.product_discount)                           AS product_discount,
           p.product_code,
           p.product_name,
           p.description,
           p.created_date,
           p.outstanding
    FROM product_detail pd
             LEFT JOIN product p
                       ON pd.product_id = p.product_id
    WHERE p.status = 1
    GROUP BY pd.product_id,
             p.product_code,
             p.product_name,
             p.description,
             p.created_date,
             p.outstanding;

-- Lấy số sp đã bán của sp
    DROP
        TEMPORARY TABLE IF EXISTS result2;
    CREATE
        TEMPORARY TABLE result2 COLLATE utf8mb4_general_ci (SELECT r1.*,
                                                                   AVG(IFNULL(c.rate, 0)) AS rate -- trung bình cộng số sao đánh giá
                                                            FROM result1 r1
                                                                     LEFT JOIN comment c
                                                                               ON r1.product_id = c.product_id
                                                            GROUP BY r1.product_id,
                                                                     r1.product_code,
                                                                     r1.product_name,
                                                                     r1.description,
                                                                     r1.created_date,
                                                                     r1.product_discount,
                                                                     r1.sale_price_old,
                                                                     r1.sale_price_min,
                                                                     r1.sale_price_max,
                                                                     r1.img_url,
                                                                     r1.outstanding,
                                                                     r1.count_detail);

    -- Lấy số sao đánh giá của sp
    DROP
        TEMPORARY TABLE IF EXISTS result3;
    CREATE
        TEMPORARY TABLE result3 COLLATE utf8mb4_general_ci
    SELECT r2.*,
           SUM(IFNULL(po.quantity, 0)) AS count_order -- Số sp đã bán: khác 4(khác đã hủy đơn)
    FROM result2 r2
             LEFT JOIN product_order po
                       ON r2.product_id = po.product_id
             LEFT JOIN `order` o
                       ON po.order_id = o.order_id
                           AND (o.status <> 4
                               OR o.status IS NULL)
         --   WHERE o.status <> 4 OR o.status IS NULL
    GROUP BY r2.product_id,
             r2.product_code,
             r2.product_name,
             r2.description,
             r2.created_date,
             r2.product_discount,
             r2.sale_price_old,
             r2.sale_price_min,
             r2.sale_price_max,
             r2.img_url,
             r2.outstanding,
             r2.count_detail,
             r2.rate;
-- Lấy danh sách sp theo nhóm Danh mục
    IF
            $category IS NOT NULL
            AND $category <> '' THEN
        CALL Proc_ConvertStringToTable($category, ',');
        DROP
            TEMPORARY TABLE IF EXISTS tmpProductCategory;
        CREATE
            TEMPORARY TABLE tmpProductCategory
        SELECT DISTINCT pc.product_id
        FROM product_category pc
                 INNER JOIN tmpListConvert tlc
                            ON pc.category_id = tlc.value;

-- Lấy tổng số bản ghi
        SELECT COUNT(*)
        INTO $totalRecord
        FROM result3 r
                 INNER JOIN tmpProductCategory tdc
                            ON r.product_id = tdc.product_id
        WHERE r.product_name LIKE CONCAT('%', IFNULL($keyword, ''), '%')
          AND ($fromAmount IS NULL
            OR r.sale_price_max >= $fromAmount)
          AND ($toAmount IS NULL
            OR r.sale_price_min <= $toAmount)
          AND ($rating IS NULL
            OR r.rate >= $rating);
-- Lấy danh sách sản phẩm
        SELECT *,
               $totalRecord AS totalRecord
        FROM result3 r
                 INNER JOIN tmpProductCategory tdc
                            ON r.product_id = tdc.product_id
        WHERE r.product_name LIKE CONCAT('%', IFNULL($keyword, ''), '%')
          AND ($fromAmount IS NULL
            OR r.sale_price_max >= $fromAmount)
          AND ($toAmount IS NULL
            OR r.sale_price_min <= $toAmount)
          AND ($rating IS NULL
            OR r.rate >= $rating)
        ORDER BY CASE WHEN $sort = 1 THEN created_date END DESC,
                 CASE WHEN $sort = 2 THEN count_order END DESC,
                 CASE WHEN $sort = 4 THEN sale_price_max END DESC,
                 CASE WHEN $sort = 3 THEN sale_price_min END ASC,
                 r.outstanding DESC
        LIMIT $pageSize OFFSET $offset;

    ELSE
        -- Lấy tổng số bản ghi
        SELECT COUNT(*)
        INTO $totalRecord
        FROM result3 r
        WHERE r.product_name LIKE CONCAT('%', IFNULL($keyword, ''), '%')
          AND ($fromAmount IS NULL
            OR r.sale_price_max >= $fromAmount)
          AND ($toAmount IS NULL
            OR r.sale_price_min <= $toAmount)
          AND ($rating IS NULL
            OR r.rate >= $rating);
-- Lấy danh sách sản phẩm
        SELECT *,
               $totalRecord AS totalRecord
        FROM result3 r
        WHERE r.product_name LIKE CONCAT('%', IFNULL($keyword, ''), '%')
          AND ($fromAmount IS NULL
            OR r.sale_price_max >= $fromAmount)
          AND ($toAmount IS NULL
            OR r.sale_price_min <= $toAmount)
          AND ($rating IS NULL
            OR r.rate >= $rating)
        ORDER BY CASE WHEN $sort = 1 THEN created_date END DESC,
                 CASE WHEN $sort = 2 THEN count_order END DESC,
                 CASE WHEN $sort = 4 THEN sale_price_max END DESC,
                 CASE WHEN $sort = 3 THEN sale_price_min END ASC,
                 r.outstanding DESC
        LIMIT $pageSize OFFSET $offset;
    END IF;


END;


create
    definer = root@localhost procedure Proc_GetProductRelation(IN $ProductId char(36), IN $Number int)
    comment 'Lấy các sản phẩm có liên quan'
    sql security invoker
BEGIN
    -- Lấy danh sách đơn hàng có sản phẩm đầu vào
    DROP
        TEMPORARY TABLE IF EXISTS tmpListProductOrder;
    CREATE
        TEMPORARY TABLE tmpListProductOrder
    SELECT DISTINCT po.order_id,
                    po.product_id
    FROM product_order po
    WHERE po.product_id = $ProductId;

    SELECT po.product_id,
           COUNT(po.product_id) AS count_relation
    FROM product_order po
             INNER JOIN tmpListProductOrder tlpo
                        ON po.order_id = tlpo.order_id
                            AND po.product_id <> tlpo.product_id
    GROUP BY po.product_id
    ORDER BY count_relation DESC
    LIMIT $Number;
END;


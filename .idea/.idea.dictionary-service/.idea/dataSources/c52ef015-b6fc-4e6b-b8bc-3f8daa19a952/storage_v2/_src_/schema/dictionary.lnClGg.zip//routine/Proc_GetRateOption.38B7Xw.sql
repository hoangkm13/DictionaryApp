create
    definer = root@localhost procedure Proc_GetRateOption(IN $product_id char(36))
    comment 'Lấy các option đánh giá'
    sql security invoker
BEGIN
    DECLARE
        $RateAll varchar(50);
    DECLARE
        $RateFive varchar(50);
    DECLARE
        $RateFour varchar(50);
    DECLARE
        $RateThree varchar(50);
    DECLARE
        $RateTwo varchar(50);
    DECLARE
        $RateOne varchar(50);
    DECLARE
        $RateHaveContent varchar(50);
    DECLARE
        $RateHaveImage varchar(50);
    DROP
        TEMPORARY TABLE IF EXISTS result;
    CREATE
        TEMPORARY TABLE result
    (
        title    varchar(50),
        rateCode varchar(20),
        active   boolean
    );
    -- Tất cả
    SELECT COUNT(c.comment_id)
    INTO $RateAll
    FROM comment c
    WHERE c.product_id = $product_id;

    INSERT INTO result (title, rateCode, active)
    VALUES (CONCAT('Tất cả (', $RateAll, ')'), 'All', TRUE);

-- 5 sao
    SELECT COUNT(c.comment_id)
    INTO $RateFive
    FROM comment c
    WHERE c.product_id = $product_id
      AND c.rate = 5;

    INSERT INTO result (title, rateCode, active)
    VALUES (CONCAT('5 Sao (', $RateFive, ')'), 'Five', FALSE);

-- 4 sao
    SELECT COUNT(c.comment_id)
    INTO $RateFour
    FROM comment c
    WHERE c.product_id = $product_id
      AND c.rate = 4;

    INSERT INTO result (title, rateCode, active)
    VALUES (CONCAT('4 Sao (', $RateFour, ')'), 'Four', FALSE);

-- 3 sao
    SELECT COUNT(c.comment_id)
    INTO $RateThree
    FROM comment c
    WHERE c.product_id = $product_id
      AND c.rate = 3;

    INSERT INTO result (title, rateCode, active)
    VALUES (CONCAT('3 Sao (', $RateThree, ')'), 'Three', FALSE);

-- 2 sao
    SELECT COUNT(c.comment_id)
    INTO $RateTwo
    FROM comment c
    WHERE c.product_id = $product_id
      AND c.rate = 2;

    INSERT INTO result (title, rateCode, active)
    VALUES (CONCAT('2 Sao (', $RateTwo, ')'), 'Two', FALSE);

-- 1 sao
    SELECT COUNT(c.comment_id)
    INTO $RateOne
    FROM comment c
    WHERE c.product_id = $product_id
      AND c.rate = 1;

    INSERT INTO result (title, rateCode, active)
    VALUES (CONCAT('1 Sao (', $RateOne, ')'), 'One', FALSE);

-- có nội dung
    SELECT COUNT(c.comment_id)
    INTO $RateHaveContent
    FROM comment c
    WHERE c.product_id = $product_id
      AND c.content IS NOT NULL
      AND c.content <> '';

    INSERT INTO result (title, rateCode, active)
    VALUES (CONCAT('Có Bình Luận (', $RateHaveContent, ')'), 'HaveContent', FALSE);

-- có hình ảnh
    SELECT COUNT(c.comment_id)
    INTO $RateHaveImage
    FROM comment c
    WHERE c.product_id = $product_id
      AND c.img_url IS NOT NULL
      AND c.img_url <> '';

    INSERT INTO result (title, rateCode, active)
    VALUES (CONCAT('Có Hình Ảnh (', $RateHaveImage, ')'), 'HaveImage', FALSE);

    SELECT *
    FROM result r;
END;


create
    definer = root@localhost procedure Proc_GetUserInfo(IN $UserId char(36))
    comment 'Lấy thông tin người dùng'
    sql security invoker
BEGIN
    SELECT u.user_id,
           u.first_name,
           u.last_name,
           u.email,
           u.phone,
           u.avatar,
           u.cart_id,
           u.gender,
           u.date_of_birth,
           u.is_block,
           IF(u.date_of_birth IS NOT NULL, DAY(u.date_of_birth), NULL)                     AS `day`,
           IF(u.date_of_birth IS NOT NULL, CONCAT('Tháng ', MONTH(u.date_of_birth)), NULL) AS `month`,
           IF(u.date_of_birth IS NOT NULL, YEAR(u.date_of_birth), NULL)                    AS `year`
    FROM user u
    WHERE u.user_id = $UserId;
END;


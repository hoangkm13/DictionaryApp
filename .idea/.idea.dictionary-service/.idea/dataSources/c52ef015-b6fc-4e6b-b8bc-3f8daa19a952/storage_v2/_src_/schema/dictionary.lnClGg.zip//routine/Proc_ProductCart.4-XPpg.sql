create
    definer = root@localhost procedure Proc_ProductCart(IN $cartId char(36))
    comment 'Lấy danh sách sp trong giỏ hàng'
    sql security invoker
BEGIN
    SELECT p.product_name,
           p.product_id,
           pd.img_url,
           pd.color_name,
           pd.size_name,
           pd.sale_price,
           pd.quantity AS quantity_max,
           pd.sale_price_old,
           pc.product_cart_id,
           pc.cart_id,
           pc.product_detail_id,
           pc.quantity,
           pc.created_date,
           FALSE       AS selected
    FROM product_cart pc
             LEFT JOIN product_detail pd
                       ON pc.product_detail_id = pd.product_detail_id
             LEFT JOIN product p
                       ON pd.product_id = p.product_id
    WHERE pc.cart_id = $cartId
    ORDER BY pc.created_date DESC;
END;


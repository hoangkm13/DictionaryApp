create
    definer = root@localhost procedure Proc_ProductInfo(IN $productId char(36))
    comment 'Lấy thông tin về sản phẩm để hiển thị trên trang bán hàng'
    sql security invoker
BEGIN
    DROP
        TEMPORARY TABLE IF EXISTS result1;
    CREATE
        TEMPORARY TABLE result1 COLLATE utf8mb4_general_ci
    SELECT pd.product_id,
           COUNT(pd.product_detail_id)                           AS count_detail,  -- số sản phẩm trong 1 loại sp
           GROUP_CONCAT(IFNULL(pd.img_url, '') SEPARATOR ';')    AS img_url,
           MAX(pd.sale_price)                                    AS sale_price_max,
           MIN(pd.sale_price)                                    AS sale_price_min,
           MAX(pd.sale_price_old)                                AS sale_price_old,
           MAX(pd.product_discount)                              AS product_discount,
           p.product_code,
           p.product_name,
           p.description,
           p.created_date,
           p.outstanding,
           GROUP_CONCAT(IFNULL(pd.color_name, '') SEPARATOR ';') AS colors,
           GROUP_CONCAT(IFNULL(pd.size_name, '') SEPARATOR ';')  AS sizes,
           SUM(IFNULL(pd.quantity, 0))                           AS total_quantity -- Lấy tổng số sp của loại sp
    FROM product_detail pd
             LEFT JOIN product p
                       ON pd.product_id = p.product_id
    WHERE p.product_id = $productId
      AND p.status = 1
    GROUP BY pd.product_id,
             p.product_code,
             p.product_name,
             p.description,
             p.created_date,
             p.outstanding;

-- Lấy số sao đánh giá của sp
    DROP
        TEMPORARY TABLE IF EXISTS result2;
    CREATE
        TEMPORARY TABLE result2 COLLATE utf8mb4_general_ci (SELECT r1.*,
                                                                   AVG(IFNULL(c.rate, 0))       AS rate, -- trung bình cộng số sao đánh giá
                                                                   COUNT(DISTINCT c.comment_id) AS count_comment
                                                            FROM result1 r1
                                                                     LEFT JOIN comment c
                                                                               ON r1.product_id = c.product_id
                                                            GROUP BY r1.product_id,
                                                                     r1.product_code,
                                                                     r1.product_name,
                                                                     r1.description,
                                                                     r1.created_date,
                                                                     r1.product_discount,
                                                                     r1.sale_price_old,
                                                                     r1.sale_price_min,
                                                                     r1.sale_price_max,
                                                                     r1.img_url,
                                                                     r1.outstanding,
                                                                     r1.count_detail,
                                                                     r1.colors,
                                                                     r1.sizes,
                                                                     r1.total_quantity);

    -- Lấy số sp đã bán của sp
    DROP
        TEMPORARY TABLE IF EXISTS result3;
    CREATE
        TEMPORARY TABLE result3 COLLATE utf8mb4_general_ci
    SELECT r2.*,
           CASE WHEN o.status <> 4 THEN SUM(IFNULL(po.quantity, 0)) ELSE 0 END AS count_order -- Số sp đã bán: khác 4(khác đã hủy đơn)
    FROM result2 r2
             LEFT JOIN product_order po
                       ON r2.product_id = po.product_id
             LEFT JOIN `order` o
                       ON po.order_id = o.order_id
    GROUP BY r2.product_id,
             r2.product_code,
             r2.product_name,
             r2.description,
             r2.created_date,
             r2.product_discount,
             r2.sale_price_old,
             r2.sale_price_min,
             r2.sale_price_max,
             r2.img_url,
             r2.outstanding,
             r2.count_detail,
             r2.rate,
             o.status,
             r2.colors,
             r2.sizes,
             r2.count_comment,
             r2.total_quantity;
    SELECT *
    FROM result3 r;
END;


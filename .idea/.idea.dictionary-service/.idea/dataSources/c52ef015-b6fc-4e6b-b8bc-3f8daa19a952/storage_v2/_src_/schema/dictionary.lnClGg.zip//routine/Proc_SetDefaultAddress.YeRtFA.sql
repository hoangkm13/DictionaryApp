create
    definer = root@localhost procedure Proc_SetDefaultAddress(IN $user_id char(36), IN $address_id char(36))
    sql security invoker
BEGIN
    UPDATE address a
    SET a.is_default = FALSE
    WHERE a.is_default = TRUE
      AND a.user_id = $user_id;

    UPDATE address a
    SET a.is_default = TRUE
    WHERE a.address_id = $address_id;
    SELECT 1;

END;


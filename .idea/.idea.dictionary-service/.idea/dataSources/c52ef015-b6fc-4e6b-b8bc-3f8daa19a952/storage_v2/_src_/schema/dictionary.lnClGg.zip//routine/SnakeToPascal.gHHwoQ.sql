create
    definer = root@`%` function SnakeToPascal(str varchar(200)) returns varchar(200) no sql
BEGIN
    DECLARE
        n,
        pos int DEFAULT 1;
    DECLARE
        sub,
        proper varchar(128) DEFAULT '';

    IF
        LENGTH(TRIM(str)) > 0 THEN
        WHILE pos > 0
            DO
                SET pos = LOCATE('_', TRIM(str), n);
                IF
                    pos = 0 THEN
                    SET sub = LOWER(TRIM(SUBSTR(TRIM(str), n)));
                ELSE
                    SET sub = LOWER(TRIM(SUBSTR(TRIM(str), n, pos - n)));
                END IF;

                SET
                    proper = CONCAT_WS('', proper, CONCAT(UPPER(LEFT(sub, 1)), SUBSTR(sub, 2)));
                SET
                    n = pos + 1;
            END WHILE;
    END IF;

    RETURN TRIM(proper);
END;

